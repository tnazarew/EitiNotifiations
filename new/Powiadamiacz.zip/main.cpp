#include <iostream>
#include <server.h>


int main() {

    EitiNotifications::Server s;

    return 0;
}